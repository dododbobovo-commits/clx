# CollatzCoin — Aurora-Net (dev)

This repository contains a research/prototype implementation of a hybrid PoW + optional validator blockchain ("CollatzCoin") and the Aurora-Net P2P protocol.

What I recently implemented in this workspace:

- A strict, implementable protocol spec companion: `docs/AURORA_SPEC_v0.9.md`.
- Stronger validation of the wire format and message fields in `aurora_protocol.py`.
- NAT + HP + relay state machine in `aurora_node.py` including STUN handling, one-way fallback and relay authorization.
- Unit tests covering protocol behaviors in `tests/test_aurora_protocol.py`.

Quick developer notes
---------------------

Run tests locally (virtualenv created by workspace tools):

```powershell
# from workspace root
.
# make sure venv is activated; then run
python -m pytest -q
```

Environment variables you can set (examples):

- AURORA_POW_BITS (default 14) — PoW difficulty for discovery
- AURORA_HP_TIMEOUT, AURORA_HP_ATTEMPTS — control HP probing behaviour
- AURORA_RELAY_SCORE, AURORA_RELAY_SCORE_THRESHOLD — relay score knobs

CI
--
We add a GitHub Actions workflow to run tests on push / pull request.

If you want a PR / branch created for review, I can create one or you can directly review local commits.  
