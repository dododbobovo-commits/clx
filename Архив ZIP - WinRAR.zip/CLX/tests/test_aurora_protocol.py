import os
import time
import os
import hashlib

from aurora_protocol import (
    build_msg_common,
    validate_incoming,
    _validate_basic_frame,
    hmac_hp,
    NODE_ID_SIZE,
    NONCE_SIZE,
    HP_NONCE_SIZE,
    TIMESTAMP_WINDOW,
)
from aurora_node import AuroraNode


class FakeTransport:
    def __init__(self):
        self.handlers = {}
        self.pub_hex = os.urandom(32).hex()
        self.node_id = os.urandom(NODE_ID_SIZE).hex()
        self.udp_port = 9001

    def register_handler(self, msg_type, handler):
        self.handlers[msg_type] = handler

    def send_msg(self, addr, msg_type, payload):
        # record what would have been sent
        self.handlers.setdefault("sent_msgs", []).append((addr, msg_type, payload))
        return True

    def send_hp_probe(self, addr, nonce, shared_token=None):
        self.handlers.setdefault("hp_probes", []).append((addr, nonce, shared_token))
        return True


def random_node_id_hex():
    return os.urandom(NODE_ID_SIZE).hex()


def test_basic_frame_bad_nodeid_and_nonce():
    # bad node_id size
    nid = os.urandom(NODE_ID_SIZE - 1)
    pub = os.urandom(32)
    msg = build_msg_common(3, nid.hex(), pub.hex(), payload={})
    ok, reason = _validate_basic_frame(msg, require_pow=False)
    assert not ok and reason == "bad_node_id"

    # bad nonce size
    nid = os.urandom(NODE_ID_SIZE)
    msg = build_msg_common(3, nid.hex(), pub.hex(), payload={})
    # manually replace a non-standard nonce
    msg[6] = b"short"
    ok, reason = _validate_basic_frame(msg, require_pow=False)
    assert not ok and reason == "bad_nonce"


def test_hp_hmac_and_nonce_size():
    token = os.urandom(32)
    nonce = os.urandom(HP_NONCE_SIZE)
    node_id = os.urandom(NODE_ID_SIZE)
    mac = hmac_hp(token, nonce, node_id)
    assert isinstance(mac, (bytes, bytearray))
    assert len(mac) == 16


def test_validate_incoming_missing_signature_rejected():
    nid_hex = random_node_id_hex()
    pub_hex = os.urandom(32).hex()
    ts = int(time.time())
    # build msg with pow set to empty - validate_incoming will expect pow when require_pow True
    msg = build_msg_common(3, nid_hex, pub_hex, payload={}, pow_nonce=os.urandom(8).hex(), timestamp=ts)
    # No signature attached -> validate_incoming must fail with bad_sig
    ok, reason = validate_incoming(msg, require_pow=False)
    assert not ok and reason == "bad_sig"


def test_on_stun_response_records_nat_info():
    t = FakeTransport()
    node = AuroraNode(t)
    # build fake STUN_RESPONSE message
    nid = os.urandom(NODE_ID_SIZE)
    msg = {1: 1, 2: 2, 3: nid, 4: os.urandom(32), 5: int(time.time()), 6: os.urandom(16), 7: {"seen_ip": "9.9.9.9", "seen_port": 54321, "nat_type": 2}}
    node._on_stun_response(msg, ("9.9.9.9", 54321))
    nid_hex = nid.hex()
    assert nid_hex in node.nat_info
    assert node.nat_info[nid_hex]["seen"] == ("9.9.9.9", 54321)


def test_hp_initiate_sends_stun_and_probes():
    t = FakeTransport()
    node = AuroraNode(t)
    # speed up probing for test
    node.HP_PROBE_TIMEOUT = 0.05
    node.HP_PROBE_ATTEMPTS = 3
    peer_ep = ("127.0.0.1", 9999)
    peer_nid = "deadbeef"
    node.hp_initiate(peer_ep, peer_nid, prefer_relay_after=100)

    sent = t.handlers.get("sent_msgs", [])
    # STUN_REQUEST should have been sent
    assert any(m[1] == 1 for m in sent)
    probes = t.handlers.get("hp_probes", [])
    assert len(probes) > 0


def test_relay_offer_requires_relay_capability(monkeypatch):
    t = FakeTransport()
    node = AuroraNode(t)
    # prevent real socket health-check
    node._relay_health_check = lambda ep: True
    nid = os.urandom(NODE_ID_SIZE)
    nid_hex = nid.hex()
    # with capability
    node.capabilities[nid_hex] = ["relay_v1"]
    payload = {"between": [nid_hex, node.t.node_id], "relay_endpoint": "udp://127.0.0.1:9999", "score": 20}
    msg = {1: 1, 2: 9, 3: nid, 4: os.urandom(32), 5: int(time.time()), 6: os.urandom(16), 7: payload}
    node._on_relay_offer(msg, ("127.0.0.1", 9999))
    sent = t.handlers.get("sent_msgs", [])
    # should have sent RELAY_ACK (MsgType.RELAY_ACK == 14)
    assert any(m[1] == 14 for m in sent)

    # without relay capability - should be rejected
    t = FakeTransport()
    node2 = AuroraNode(t)
    node2._relay_health_check = lambda ep: True
    nid2 = os.urandom(NODE_ID_SIZE)
    payload2 = {"between": [nid2.hex(), node2.t.node_id], "relay_endpoint": "udp://127.0.0.1:9999", "score": 20}
    msg2 = {1: 1, 2: 9, 3: nid2, 4: os.urandom(32), 5: int(time.time()), 6: os.urandom(16), 7: payload2}
    node2._on_relay_offer(msg2, ("127.0.0.1", 9999))
    sent2 = t.handlers.get("sent_msgs", [])
    assert not sent2


def test_hp_ack_and_success_transition():
    t = FakeTransport()
    node = AuroraNode(t)
    nid = os.urandom(NODE_ID_SIZE).hex()
    # simulate starting HP flow for a peer
    node.peer_state[nid] = "HP"
    # HP_ACK incoming
    msg = {1: 1, 2: 13, 3: bytes.fromhex(nid), 4: os.urandom(32), 5: int(time.time()), 6: os.urandom(16), 7: {"nonce": b"", "mac": b""}}
    # also add peer info so _on_hp_success will mark peer validated
    node.peers[nid] = type("P", (), {"endpoints": ["udp://1.2.3.4:11111"], "last_seen": int(time.time()), "node_id": nid, "role_flags": 0, "score_hint": 0})()
    node._on_hp_ack(msg, ("1.2.3.4", 11111))
    assert node.peer_state.get(nid) == "HP_ACK"
    # simulate full HP success (on_hp) -> should set OK and validated
    node._on_hp_success(msg, ("1.2.3.4", 11111))
    assert node.peer_state.get(nid) == "OK"
    assert nid in node.validated_peers


def test_request_relay_includes_score(monkeypatch):
    t = FakeTransport()
    node = AuroraNode(t)
    monkeypatch.setenv("AURORA_RELAY_SCORE", "42")
    node.request_relay(("127.0.0.1", 9999), [node.t.node_id, "foobar"])
    sent = t.handlers.get("sent_msgs", [])
    # we expect a RELAY_OFFER (MsgType.RELAY_OFFER == 9) to have been sent
    matches = [m for m in sent if m[1] == 9]
    assert matches
    # check payload contains score 42
    payload = matches[0][2]
    assert payload.get("score") == 42


def test_on_relay_offer_registers_session(monkeypatch):
    t = FakeTransport()
    node = AuroraNode(t)
    node._relay_health_check = lambda ep: True
    nid = os.urandom(NODE_ID_SIZE)
    nid_hex = nid.hex()
    node.capabilities[nid_hex] = ["relay_v1"]
    payload = {"between": [nid_hex, node.t.node_id], "relay_endpoint": "udp://127.0.0.1:9999", "score": 50}
    msg = {1: 1, 2: 9, 3: nid, 4: os.urandom(32), 5: int(time.time()), 6: os.urandom(16), 7: payload}
    node._on_relay_offer(msg, ("127.0.0.1", 9999))
    # relay_sessions should contain entry for the relay endpoint
    assert "udp://127.0.0.1:9999" in node.relay_sessions


def test_dedup_cache_behavior():
    from aurora_transport import DedupCache
    d = DedupCache(ttl=1, max_size=10)
    mid = b"\x00\x01\x02"
    assert not d.seen(mid)
    assert d.seen(mid)
    # after TTL expires, seen() should return False once pruned
    import time
    time.sleep(1.1)
    assert not d.seen(mid)


def test_on_peer_list_sets_pending_and_requires_hp():
    t = FakeTransport()
    node = AuroraNode(t)
    # ensure signature and pow checks pass (we're testing downstream behavior)
    import aurora_protocol as _ap
    _ap.verify_msg_signature = lambda msg: True
    node._check_pow = lambda msg: True
    # create a peer_list message with one peer
    nid = os.urandom(NODE_ID_SIZE).hex()
    peer_entry = {"node_id": nid, "endpoints": ["udp://10.0.0.1:12345"], "last_seen": int(time.time())}
    msg = {1: 1, 2: 10, 3: os.urandom(NODE_ID_SIZE), 4: os.urandom(32), 5: int(time.time()), 6: os.urandom(16), 7: {"peers": [peer_entry]}}
    node._on_peer_list(msg, ("8.8.8.8", 1234))
    # peer should be present in pending_peers and pending_hp but not yet validated
    assert nid in node.pending_peers
    assert any("udp://10.0.0.1:12345" in ep for ep in node.pending_hp.keys())
    assert nid not in node.validated_peers


def test_room_creation_rate_limit(monkeypatch):
    t = FakeTransport()
    node = AuroraNode(t)
    coord_nid = os.urandom(NODE_ID_SIZE).hex()
    # create 3 room_create messages; only first two should be accepted
    payload = {"room_id": os.urandom(8).hex(), "participants": [{"node_id": node.t.node_id}], "ttl": 15, "roles": ["stun_candidate"]}
    msg = {1: 1, 2: 5, 3: bytes.fromhex(coord_nid), 4: os.urandom(32), 5: int(time.time()), 6: os.urandom(16), 7: payload}
    node._on_room_create(msg, ("1.2.3.4", 1111))
    node._on_room_create(msg, ("1.2.3.4", 1111))
    node._on_room_create(msg, ("1.2.3.4", 1111))
    # recent_rooms should include at most 2 entries for this coordinator in a 60s window
    assert node.recent_rooms.count(coord_nid) <= 2


def test_nat_classification_and_mode(monkeypatch):
    t = FakeTransport()
    node = AuroraNode(t)
    # simulate peer STUN response saying peer is symmetric
    peer_nid = os.urandom(NODE_ID_SIZE).hex()
    node.nat_info[peer_nid] = {"seen": ("1.2.3.4", 40000), "nat_type": 3}
    # local NAT type set to 0
    monkeypatch.setenv("AURORA_NAT_TYPE", "0")
    assert node.classify_nat_type(peer_nid) == 3
    assert node.get_local_nat_type() == 0
    # mix of local 0 and remote 3 -> ONEWAY
    assert node.decide_connection_mode(peer_nid) == "ONEWAY"

    # both symmetric -> RELAY
    monkeypatch.setenv("AURORA_NAT_TYPE", "3")
    assert node.get_local_nat_type() == 3
    assert node.decide_connection_mode(peer_nid) == "RELAY"

    # neither symmetric -> HP
    node.nat_info[peer_nid]["nat_type"] = 1
    monkeypatch.setenv("AURORA_NAT_TYPE", "1")
    assert node.decide_connection_mode(peer_nid) == "HP"
