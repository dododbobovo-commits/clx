import os
import time

from aurora_node import AuroraNode


class DummyTransport:
    def __init__(self):
        self.handlers = {}
        self.pub_hex = os.urandom(32).hex()
        self.node_id = os.urandom(32).hex()
        self.udp_port = 9002

    def register_handler(self, msg_type, handler):
        self.handlers[msg_type] = handler

    def send_msg(self, addr, msg_type, payload):
        # For integration tests we simulate peer interactions by calling any registered handler on other side
        return True

    def send_hp_probe(self, addr, nonce, shared_token=None):
        # record a sent probe for simplicity
        self.handlers.setdefault("hp_probes", []).append((addr, nonce, shared_token))
        return True


def test_two_nodes_hp_and_relay_flow():
    # Setup two nodes with dummy transports
    t1 = DummyTransport()
    t2 = DummyTransport()
    node1 = AuroraNode(t1, bootstrap_peers=[("127.0.0.1", 9999)])
    node2 = AuroraNode(t2, bootstrap_peers=[("127.0.0.1", 9999)])

    # Ensure health check stubbed
    node1._relay_health_check = lambda ep: True
    node2._relay_health_check = lambda ep: True

    # Simulate node1 learning node2 via peer_list
    nid2 = t2.node_id
    p = {"node_id": nid2, "endpoints": [f"udp://127.0.0.1:{t2.udp_port}"], "last_seen": int(time.time())}
    msg = {1: 1, 2: 10, 3: os.urandom(32), 4: os.urandom(32), 5: int(time.time()), 6: os.urandom(16), 7: {"peers": [p]}}
    # patch signature and pow validators
    import aurora_protocol as _ap
    _ap.verify_msg_signature = lambda msg: True
    node1._check_pow = lambda msg: True

    node1._on_peer_list(msg, ("127.0.0.1", 9999))
    # hp_initiate should have been scheduled; call directly
    node1.hp_initiate(("127.0.0.1", t2.udp_port), nid2)
    # hp probes recorded
    assert t1.handlers.get("hp_probes")

    # Request relay from coordinator: should create a session meta in node2 when accepted
    nid1 = t1.node_id
    # set capabilities for node2 so it will accept relay
    node2.capabilities[nid2] = ["relay_v1"]
    node2._on_relay_offer({1:1,2:9,3:bytes.fromhex(nid2),4:os.urandom(32),5:int(time.time()),6:os.urandom(16),7:{"between":[nid1,nid2],"relay_endpoint":f"udp://127.0.0.1:{t2.udp_port}","score":20}}, ("127.0.0.1", 9999))
    assert f"udp://127.0.0.1:{t2.udp_port}" in node2.relay_sessions
