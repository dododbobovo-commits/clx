# CHANGES — aurora-protocol-v0.9

This file summarizes the local changeset for the Aurora-Net v0.9 work performed in this workspace.

Summary (high level):

- Implemented strict wire-format validation (CBOR frame checks, nonce/node_id/signature sizes) in `aurora_protocol.py`.
- Added HMAC-based HP probe authentication and stricter PoW checks.
- Implemented STUN request/response handlers, NAT classification and heuristics in `aurora_node.py`.
- Implemented hole-punching state-machine with aggressive probing, one-way fallback and relay escalation.
- Enforced relay authorization policies, session tracking, and quotas.
- Hardened discovery/peer_list and room_create anti-eclipse rules.
- Added comprehensive unit tests and a small integration test suite.
- Added CI workflow and README for project and protocol.

This change is contained in a local branch: `restructure/aurora-protocol-v0.9`.
