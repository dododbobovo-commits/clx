# AURORA-NET P2P PROTOCOL — SPEC v0.9 (implementation companion)

This companion document summarizes the strict, implementable protocol rules for Aurora-Net v0.9.

Key points (implementation-focused):

- Wire format: CBOR for all wire messages. Strict, fixed keys as integers; maximal encoded size 2048 bytes.
- Message frame keys: 1: version, 2: type, 3: node_id (32 bytes), 4: pubkey (32/33),
  5: timestamp (int), 6: nonce (16 bytes), 7: payload(map), 8: signature (64 bytes), 9: pow_nonce (optional bytes).
- Nonce size, node_id size and timestamp window are enforced.
- Messages requiring PoW: announce, discovery, room_create, room_join, peer_list, relay_offer, relay_data.
- HP probe/ack use HMAC with shared_token; the HP payload must be exactly {nonce: 8 bytes, mac: 16 bytes (if used)}.
    HP probing algorithm (implementation note): initiate STUN, then perform aggressive HP probing phase for up to 3s (~50 probes),
    fallback to One-Way for 2s, then request Relay if still unsuccessful. One-Way attempt count and HP probe tunables
    are parametrized by AURORA_HP_TIMEOUT and AURORA_HP_ATTEMPTS.
- Deduping uses msg_id = sha256(type||nonce||node_id) and caches 1024 IDs for 60s.
- Rate limits and soft-ban durations are configurable (see constants in code).
    Discovery / room limits: per-coordinator max 2 rooms / min; recent room-ID replay cache (last 256) is maintained to prevent replay-based eclipse.
- Capability negotiation and version checks are mandatory during exchange; mismatch => soft-ban.

Relay / HP / NAT behavior specification is described in the main design doc (project tracking), and this companion file is intended for implementers to reference strict field sizes, checks and behaviors.

See `aurora_protocol.py` for the authoritative validation helpers and `tests/test_aurora_protocol.py` for example test cases used to validate the behavior.
